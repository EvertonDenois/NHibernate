﻿using System;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using System.Reflection;
using NHibernate.Tool.hbm2ddl;
using System.Configuration;

namespace ConsoleNH.Infra
{
    class Config : IDisposable
    {
        public ISession Session;
        public ITransaction Transaction;
        public static ISessionFactory SessionFactory;

        public Config()
        {
            SessionFactory = CreateSessionFactory();
            Session = SessionFactory.OpenSession();
            Transaction = Session.BeginTransaction();
        }

        private static ISessionFactory CreateSessionFactory()
        {
            var pathScriptBanco = ConfigurationManager.AppSettings["PathScriptDataBase"];

            return SessionFactory ?? (SessionFactory = Fluently.Configure()
                                                               .Database(MsSqlConfiguration.MsSql2008.ConnectionString(
                                                                    c => c.FromConnectionStringWithKey("bd_testeConnectionString")).ShowSql())
                                                               .Mappings(
                                                                    x =>
                                                                    x.FluentMappings.AddFromAssembly(
                                                                        Assembly.GetExecutingAssembly()))

                                .ExposeConfiguration(cfg => new SchemaExport(cfg).SetOutputFile(pathScriptBanco.ToString()).Create(false, true))
                                                            .BuildSessionFactory());
        }

        public void Dispose()
        {
            if (SessionFactory != null)
            {
                SessionFactory.Dispose();
            }
        }
    }
}
